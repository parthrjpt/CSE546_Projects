import make_env
import time
import numpy as np
import gym
from gym import spaces
import matplotlib.pyplot as plt
from collections import deque
import random

import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torch.optim as optim
from torch.autograd import Variable





class MTNET(nn.Module):
    def __init__(self, ):
        super(MTNET, self).__init__()
        self.fc1 = nn.Linear(10, 128)
        self.fc1.weight.data.normal_(0, 0.1)
        self.fc2 = nn.Linear(128, 64)
        self.fc2.weight.data.normal_(0, 0.1)
        self.fc3 = nn.Linear(64, 9)
        self.fc3.weight.data.normal_(0, 0.1)

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.fc3(x)
        return x
class MTNET1(nn.Module):
    def __init__(self, ):
        super(MTNET1, self).__init__()
        self.fc1 = nn.Linear(8, 128)
        self.fc1.weight.data.normal_(0, 0.1)
        self.fc2 = nn.Linear(128, 64)
        self.fc2.weight.data.normal_(0, 0.1)
        self.fc3 = nn.Linear(64, 9)
        self.fc3.weight.data.normal_(0, 0.1)

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.fc3(x)
        return x

def set_action(a):
  actions = [0]*5
  if a<5:
    actions[a]=1
  elif a == 5:
    actions[1] = 1
    actions[3] = 1
  elif a == 6:
    actions[1] = 1
    actions[4] = 1
  elif a == 7:
    actions[2] = 1
    actions[3] = 1
  elif a == 8:
    actions[2] = 1
    actions[4] = 1
  return actions


BATCH_SIZE = 120
MIN_BATCH_SIZE = 120
MAX_REPLAY_BUFFER_SIZE = 2000
EPSILON = 1

UPDATE = 100
GAMMA = 0.9



class MTDQNAgent:
    def __init__(self, env):
        self.env = env
        self.replay_mem = np.zeros((MAX_REPLAY_BUFFER_SIZE, 22))
        self.model = MTNET()
        self.target_model = MTNET()
        self.n_action = 9
        self.n_state = 10
        self.loss_func = nn.MSELoss()
        self.optimizer = optimizer = optim.Adam(self.model.parameters())
        self.learn_counter = 0
        self.memory_counter = 0
        

    def choose_action(self, x):
        x = torch.unsqueeze(torch.FloatTensor(x), 0)
        # input only one sample
        if np.random.uniform() > EPSILON:   # greedy
            actions_value = self.model.forward(x)
            action = torch.max(actions_value, 1)[1].data.numpy()[0]
        else:   # random
            action = np.random.randint(0, self.n_action)
        return action
        
    def store_mem(self, s, a, r, s_):
      transition = np.hstack((s, [a, r], s_))
      index = self.memory_counter % MAX_REPLAY_BUFFER_SIZE
      self.replay_mem[index, :] = transition
      self.memory_counter += 1

    def learn(self):
        if len(self.replay_mem) < MIN_BATCH_SIZE:
          return
        if self.learn_counter % UPDATE == 0:
          # print("----------------------update-----------------")
          self.target_model.load_state_dict(self.model.state_dict())
        self.learn_counter += 1
        sample_index = np.random.choice(MAX_REPLAY_BUFFER_SIZE, BATCH_SIZE)
        b_memory = self.replay_mem[sample_index, :]
        b_s = torch.FloatTensor(b_memory[:, :self.n_state])
        b_a = torch.LongTensor(b_memory[:, self.n_state:self.n_state+1].astype(int))
        b_r = torch.FloatTensor(b_memory[:, self.n_state+1:self.n_state+2])
        b_s_ = torch.FloatTensor(b_memory[:, -self.n_state:])

        # q_eval w.r.t the action in experience
        q_eval = self.model(b_s).gather(1, b_a)  # shape (batch, 1)
        q_next = self.target_model(b_s_).detach()     # detach from graph, don't backpropagate
        q_target = b_r + GAMMA * q_next.max(1)[0].view(BATCH_SIZE, 1)   # shape (batch, 1)
        loss = self.loss_func(q_eval, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


class MTDQNADVERSARY:
    def __init__(self, env):
        self.env = env
        self.replay_mem = np.zeros((MAX_REPLAY_BUFFER_SIZE, 18))
        self.model = MTNET1()
        self.target_model = MTNET1()
        self.n_action = 9
        self.n_state = 8
        self.loss_func = nn.MSELoss()
        self.optimizer = optimizer = optim.Adam(self.model.parameters())
        self.learn_counter = 0
        self.memory_counter = 0
        

    def choose_action(self, x):
        x = torch.unsqueeze(torch.FloatTensor(x), 0)
        # input only one sample
        if np.random.uniform() > EPSILON:   # greedy
            actions_value = self.model.forward(x)
            action = torch.max(actions_value, 1)[1].data.numpy()[0]
        else:   # random
            action = np.random.randint(0, self.n_action)
        return action
        
    def store_mem(self, s, a, r, s_):
      transition = np.hstack((s, [a, r], s_))
      index = self.memory_counter % MAX_REPLAY_BUFFER_SIZE
      self.replay_mem[index, :] = transition
      self.memory_counter += 1

    def learn(self):
        if len(self.replay_mem) < MIN_BATCH_SIZE:
          return
        if self.learn_counter % UPDATE == 0:
          # print("----------------------update-----------------")
          self.target_model.load_state_dict(self.model.state_dict())
        self.learn_counter += 1
        sample_index = np.random.choice(MAX_REPLAY_BUFFER_SIZE, BATCH_SIZE)
        b_memory = self.replay_mem[sample_index, :]
        b_s = torch.FloatTensor(b_memory[:, :self.n_state])
        b_a = torch.LongTensor(b_memory[:, self.n_state:self.n_state+1].astype(int))
        b_r = torch.FloatTensor(b_memory[:, self.n_state+1:self.n_state+2])
        b_s_ = torch.FloatTensor(b_memory[:, -self.n_state:])

        # q_eval w.r.t the action in experience
        q_eval = self.model(b_s).gather(1, b_a)  # shape (batch, 1)
        q_next = self.target_model(b_s_).detach()     # detach from graph, don't backpropagate
        q_target = b_r + GAMMA * q_next.max(1)[0].view(BATCH_SIZE, 1)   # shape (batch, 1)
        loss = self.loss_func(q_eval, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

# def particle_env_DQN():
env = make_env.make_env('simple_adversary')
agentA = MTDQNADVERSARY(env)
agentB = MTDQNAgent(env)
agentC = MTDQNAgent(env)
decay = 0.995
EPSILON = 1
R1 = []
R2 = []
R3 = []
avg = []
ep_num = 1000
m = 0
for i in range(ep_num):
  observation = env.reset()
  done = False
  scoreA = 0
  scoreB = 0
  obs = []
  for k in range(len(observation)):
      obs.append(observation[k])
  for j in range(25):
      A = agentA.choose_action(obs[0])
      B = agentB.choose_action(obs[1])
      C = agentC.choose_action(obs[2])
      # print(A, B, C)
      action_A = set_action(A)
      action_B = set_action(B)
      action_C = set_action(C)
      observation, reward, done, info = env.step([action_A, action_B, action_C])
      obs_ = []
      for k in range(len(observation)):
        obs_.append(observation[k])
      agentA.store_mem(obs[0], A, reward[0], obs_[0])
      agentB.store_mem(obs[1], B, reward[1], obs_[1])
      agentB.store_mem(obs[2], C, reward[2], obs_[2])
      r1, r2, r3 = reward
      scoreA += r1
      scoreB += r2+r3
      obs = obs_
      
      if (m+1)%5 == 0:
        agentA.learn()
        agentB.learn()
        agentC.learn()
      m+=1
      # if i%100 == 0:
      #   env.render()
      #   time.sleep(0.2)
  # print('episode ', i+1, ' reward: ', scoreA+scoreB)
  # print('episode ', i+1, EPSILON)
  EPSILON = EPSILON-2/ep_num if EPSILON > 0.01 else 0.01
  # EPSILON = EPSILON*decay if EPSILON>0.01 else 0.01
  R1.append(scoreA)
  R2.append(scoreB)
  R3.append(scoreA+scoreB)
  avg.append((sum(R3[-20:])-min(R3[-20:])-max(R3[-20:]))/18)
  

# plt.plot(R1)
plt.figure(1)
plt.plot(avg)
plt.title('Average Rewards')
plt.savefig('Average_Score.png', dpi = 500)
plt.show()
plt.figure(2)
plt.plot(R1, label='A')
plt.plot(R2, label='B')
plt.title('Rewards of Agents & Adversary')
plt.savefig('particle_DQN_Agent_rewards.png', dpi = 500)
plt.show()
plt.figure(3)
plt.plot(R3)
plt.show()
