# -*- coding: utf-8 -*-
"""
Created on Fri Apr 30 12:03:50 2021

@author: parth
"""

import numpy as np
import matplotlib.pyplot as plt
import gym
from gym import spaces
import time
import copy
import random
from collections import deque
import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torch.optim as optim
from torch.autograd import Variable

class MultiAgentEnv(gym.Env):
    """5x5 Environment
      chaser initial state: [0, 0]
      runner initial state: [4, 4]
      portal: [4, 0] and [0, 4], step into one of the portals will teleport to anther portal
    """

    """Chaser gets reward 1 when catching the runner, -1 when runner escaped
      runner gets reward 1 when escaped, -1 otherwise
    """
    def __init__(self):
        self.max_steps = 40
        self.action_space = spaces.Discrete(5)
        self.obs_space = spaces.Discrete(25)
        self.ate = False
        
    def reset(self):
        self.timestep = 0
        self.agentA_pos = [1, 1]
        self.agentB_pos = [4, 4]
        self.teleIn = [4, 0]
        self.teleOut = [0, 4]
        self.state = np.zeros((5, 5))
        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        return observation
    
    def step(self, actionA, actionB):
        if actionA == 0:
          self.agentA_pos[0] += 1
        if actionA == 1:
          self.agentA_pos[0] -= 1
        if actionA == 2:
          self.agentA_pos[1] += 1
        if actionA == 3:
          self.agentA_pos[1] -= 1

        if actionB == 0:
          self.agentB_pos[0] += 1
        if actionB == 1:
          self.agentB_pos[0] -= 1
        if actionB == 2:
          self.agentB_pos[1] += 1
        if actionB == 3:
          self.agentB_pos[1] -= 1
          
        self.agentA_pos = np.clip(self.agentA_pos, 0, 4)
        self.agentB_pos = np.clip(self.agentB_pos, 0, 4)

        if (self.agentA_pos == self.teleIn).all():
          self.agentA_pos = np.copy(self.teleOut)
        elif (self.agentA_pos == self.teleOut).all():
          self.agentA_pos = np.copy(self.teleIn)
        if (self.agentB_pos == self.teleIn).all():
          self.agentB_pos = np.copy(self.teleOut)
        elif (self.agentB_pos == self.teleOut).all():
          self.agentB_pos = np.copy(self.teleIn)
        self.state = np.zeros((5,5))

        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        done = False
        self.timestep += 1
        rewardA = 0
        rewardB = 0
        if (self.agentA_pos == self.agentB_pos).all():
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[0] == self.agentB_pos[0] and abs(self.agentA_pos[1] -self.agentB_pos[1])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[1] == self.agentB_pos[1] and abs(self.agentA_pos[0] -self.agentB_pos[0])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.timestep ==self.max_steps:
          rewardA = -1
          rewardB = 1
          done = True
        info = {}
        return observation, (rewardA, rewardB), done, info
        
    def render(self):
        plt.imshow(self.state)

class Model(nn.Module):
    def __init__(self, ):
        super(Model, self).__init__()
        self.fc1 = nn.Linear(4, 128)
        self.fc2 = nn.Linear(128, 128)
        self.relu=nn.ReLU()
        self.learn_V = nn.Linear(128, env.action_space.n)
        self.learn_A  = nn.Linear(128, 1)

    def forward(self, x):
        x = self.fc1(x)
        opl1 = self.relu(x)
        opl2 = self.fc2(opl1)
        opl2 = self.relu(opl2)     
        a = self.learn_A(opl2)
        v = self.learn_V(opl2)
        return v + (a - a.max(1, keepdim=True)[0])

BATCH_SIZE = 50
MIN_BATCH_SIZE = 50
MAX_REPLAY_BUFFER_SIZE = 1200
EPSILON = 1
env = MultiAgentEnv()
N_ACTIONS = env.action_space.n
N_STATES=25
UPDATE = 100
GAMMA = 0.9
ENV_A_SHAPE = 0 if isinstance(env.action_space.sample(), int) else env.action_space.sample().shape

class DuelDQNMultiAgent:
    def __init__(self, env):
        self.env = env
        self.replay_mem = deque(maxlen = MAX_REPLAY_BUFFER_SIZE)
        self.model = Model()
        self.target_model = Model()
        self.loss_func = nn.MSELoss()
        self.optimizer = optimizer = optim.Adam(self.model.parameters())
        # self.optimizer = optim.SGD(self.model.parameters(), lr=0.001, momentum=0.9)
        self.target_model.fc1.weight = self.model.fc1.weight
        self.target_model.fc2.weight = self.model.fc2.weight
        self.learn_counter = 0
        self.memory_counter = 0
        

    def step(self, x):
        x = Variable(torch.unsqueeze(torch.FloatTensor(x), 0))
        if np.random.uniform() > EPSILON:
          actions = self.model(x)
          action = torch.max(actions, 1)[1].data.numpy()
          action = action[0]
          # print(actions, action)
        else:
          action = np.random.randint(4)
        return action
        
    def store_mem(self, state, action, reward, next_state, done):
      self.replay_mem.append((state, action, reward, next_state, done))

    def train(self):
        if len(self.replay_mem) < MIN_BATCH_SIZE:
          return
        if self.learn_counter % UPDATE == 0:
          # print("----------------------update-----------------")
          # self.target_model.load_state_dict(self.model.state_dict())
          self.target_model.fc1.weight = self.model.fc1.weight
          self.target_model.fc2.weight = self.model.fc2.weight
        self.learn_counter += 1
        batch = random.sample(self.replay_mem, BATCH_SIZE)
        s, a, r, s_, done = (list(col) for col in zip(*batch))

        s = torch.FloatTensor(s)
        a = torch.LongTensor(a)
        r = torch.FloatTensor(r).view(BATCH_SIZE,1)
        s_ = torch.FloatTensor(s_)
        q_val = self.model(s)
        q_next = self.target_model(s_)  

        q_target = torch.tensor([q_next[i].max() for i in range(BATCH_SIZE)])
        q_ = q_val[:, 0]
        for i in range(len(done)):
          q_[i] = q_val[i][a[i]]
          if done[i]:
            q_target[i] = r[i]
        # print(q_.shape, q_target.shape)
        
        q_target = torch.FloatTensor(q_target)

        loss = self.loss_func(q_, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

env = MultiAgentEnv()
env.reset()
agentA = DuelDQNMultiAgent(env)
agentB = DuelDQNMultiAgent(env)
decay = 0.995
EPSILON = 1
MTDuelDQNplotA=[]
MTDuelDQNplotB=[]
n_games = 1000
k=0

for i in range(n_games):
  env.reset()
  done = False
  culRewardA = 0
  culRewardB = 0
  while not done:
    k+=1
    s = [env.agentA_pos[0], env.agentA_pos[1], env.agentB_pos[0], env.agentB_pos[1]]
    actionA = agentA.step(s)
    actionB = agentB.step(s)
    obs, reward, done, info = env.step(actionA, actionB)
    s_ = [obs[0][0], obs[0][1], obs[1][0], obs[1][1]]
    agentA.store_mem(s, actionA, reward[0], s_, done)
    agentB.store_mem(s, actionB, reward[1], s_,done)
    if k%5 == 1:
      agentA.train()
      agentB.train()
    culRewardA+=reward[0]
    culRewardB+=reward[1]
  # EPSILON = EPSILON*decay if EPSILON > 0.01 else 0.01
  EPSILON = EPSILON - 2/n_games if EPSILON > 0.01 else 0.01
  MTDuelDQNplotA.append(culRewardA)
  MTDuelDQNplotB.append(culRewardB)  
  
plt.plot(MTDuelDQNplotA)
plt.title('MA agent A reward per ep')
plt.xlabel('episodes')
plt.ylabel('cumulativereward')
plt.savefig('Grid world Dueling DQN agent A.png', dpi = 500)
plt.show()
plt.plot(MTDuelDQNplotB)
plt.title('MA agent B reward per ep')
plt.xlabel('episodes')
plt.ylabel('cumulativereward')
plt.savefig('Grid world Dueling DQN agent B.png', dpi = 500)

plt.show()

multiEpsilon=[]
EPSILON = 1

while EPSILON>=0.01:
  multiEpsilon.append(EPSILON)
  EPSILON = EPSILON - 2/n_games
  
plt.plot(multiEpsilon)
plt.title('multiagent epsilon')
plt.xlabel('episode')
plt.ylabel('epsilon')
plt.show()