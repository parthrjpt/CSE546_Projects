import numpy as np
import matplotlib.pyplot as plt
import gym
from gym import spaces
import time
import copy
import random
from collections import deque
import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torch.optim as optim
from torch.autograd import Variable



class MultiAgentEnv(gym.Env):
    """5x5 Environment
      chaser initial state: [0, 0]
      runner initial state: [4, 4]
      portal: [4, 0] and [0, 4], step into one of the portals will teleport to anther portal
    """

    """Chaser gets reward 1 when catching the runner, -1 when runner escaped
      runner gets reward 1 when escaped, -1 otherwise
    """
    def __init__(self):
        self.max_steps = 40
        self.action_space = spaces.Discrete(5)
        self.obs_space = spaces.Discrete(25)
        self.ate = False
        
    def reset(self):
        self.timestep = 0
        self.agentA_pos = [1, 1]
        self.agentB_pos = [4, 4]
        self.teleIn = [4, 0]
        self.teleOut = [0, 4]
        self.state = np.zeros((5, 5))
        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        return observation
    
    def step(self, actionA, actionB):
        if actionA == 0:
          self.agentA_pos[0] += 1
        if actionA == 1:
          self.agentA_pos[0] -= 1
        if actionA == 2:
          self.agentA_pos[1] += 1
        if actionA == 3:
          self.agentA_pos[1] -= 1

        if actionB == 0:
          self.agentB_pos[0] += 1
        if actionB == 1:
          self.agentB_pos[0] -= 1
        if actionB == 2:
          self.agentB_pos[1] += 1
        if actionB == 3:
          self.agentB_pos[1] -= 1
          
        self.agentA_pos = np.clip(self.agentA_pos, 0, 4)
        self.agentB_pos = np.clip(self.agentB_pos, 0, 4)

        if (self.agentA_pos == self.teleIn).all():
          self.agentA_pos = np.copy(self.teleOut)
        elif (self.agentA_pos == self.teleOut).all():
          self.agentA_pos = np.copy(self.teleIn)
        if (self.agentB_pos == self.teleIn).all():
          self.agentB_pos = np.copy(self.teleOut)
        elif (self.agentB_pos == self.teleOut).all():
          self.agentB_pos = np.copy(self.teleIn)
        self.state = np.zeros((5,5))

        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        done = False
        self.timestep += 1
        rewardA = 0
        rewardB = 0
        if (self.agentA_pos == self.agentB_pos).all():
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[0] == self.agentB_pos[0] and abs(self.agentA_pos[1] -self.agentB_pos[1])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[1] == self.agentB_pos[1] and abs(self.agentA_pos[0] -self.agentB_pos[0])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.timestep ==self.max_steps:
          rewardA = -1
          rewardB = 1
          done = True
        info = {}
        return observation, (rewardA, rewardB), done, info
        
    def render(self):
        plt.imshow(self.state)

class RandomAgent:
    def __init__(self, env):
        self.obs_space = env.obs_space
        self.action_space = env.action_space
        self.env = env
        
    def step(self, observation):
        return np.random.choice(self.action_space.n)

env = MultiAgentEnv()
agentA = RandomAgent(env)
agentB = RandomAgent(env)
episode_num = 2000
gamma = 0.9
epsil = 1
alph = 0.2
decay = 0.995
epsil_min = 0.01
env.reset()
# initialize Q table
QA = {}
QB = {}
for i in range(5):
  for j in range(5):
    for n in range(5):
      for m in range(5):
        QA[i, j, n, m] = [0 for k in range(4)]
        QB[i, j, n, m] = [0 for k in range(4)]
Q_A = []
Q_B = []
Q_det_axis = []
Q_det_epsil = []

# for episode in range(episode_num):
#   print(epsil)
#   epsil = epsil*decay if epsil>0.01 else 0.01
# Q learning update
for episode in range(episode_num):
  s1, s2 = env.reset()
  ep_rewardA = 0
  ep_rewardB = 0
  Q_det_axis.append(episode)
  for steps in range(env.max_steps):
    agentA.obs_space = s1
    agentB.obs_space = s2
    # print(agentA.obs_space, agentB.obs_space)
    coorX = s1[0]
    coorY = s1[1]
    coorBX = s2[0]
    coorBY = s2[1]
    if np.random.uniform(0, 1) > epsil:
      A = np.argmax(QA[coorX, coorY, coorBX, coorBY])
      B = np.argmax(QB[coorBX, coorBY, coorX, coorY])
    else:
      A = np.random.randint(4)
      B = np.random.randint(4)
    obs, reward, done, info = env.step(A, B)
    ep_rewardA += reward[0]
    ep_rewardB += reward[1]
    A_ = np.argmax(QA[obs[0][0], obs[0][1], coorBX, coorBY])
    B_ = np.argmax(QB[obs[1][0], obs[1][1], coorX, coorY])
    QA[coorX, coorY, coorBX, coorBY][A] = QA[coorX, coorY, coorBX, coorBY][A] + alph*(reward[0] + gamma*QA[obs[0][0], obs[0][1], coorBX, coorBY][A_] - QA[coorX, coorY, coorBX, coorBY][A])
    QB[coorBX, coorBY, coorX, coorY][B] = QB[coorBX, coorBY, coorX, coorY][B] + alph*(reward[1] + gamma*QB[obs[1][0], obs[1][1], coorX, coorY][B_] - QB[coorBX, coorBY, coorX, coorY][B])
    s1 = obs[0]
    s2 = obs[1]
    # render visualization, uncomment to enable visualization
    # with output_grid.output_to(0, 0):
    #   output_grid.clear_cell()
    #   env.render()
    # time.sleep(0.1)
    if done:
      break
  Q_det_epsil.append(epsil)
  Q_A.append(ep_rewardA)
  Q_B.append(ep_rewardB)
  epsil = epsil - 2/episode_num if epsil > 0.01 else 0.01
  # epsil = epsil*decay if epsil > 0.01 else 0.01


# for episode in range(5):
#   s1, s2 = env.reset()
#   ep_rewardA = 0
#   ep_rewardB = 0
#   Q_det_axis.append(episode)
#   for steps in range(env.max_steps):
#     agentA.obs_space = s1
#     agentB.obs_space = s2
#     coorX = s1[0]
#     coorY = s1[1]
#     coorBX = s2[0]
#     coorBY = s2[1]
#     if np.random.uniform(0, 1) > epsil:
#       A = np.argmax(QA[s1[0], s1[1]])
#       B = np.argmax(QB[s2[0], s2[1]])
#     else:
#       A = np.random.randint(4)
#       B = np.random.randint(4)
#     obs, reward, done, info = env.step(A, B)
#     ep_rewardA += reward[0]
#     ep_rewardB += reward[1]

#     QA[coorX, coorY][A] = QA[coorX, coorY][A] + alph*(reward[0] + gamma*np.argmax(QA[obs[0][0], obs[0][1]]) - QA[coorX, coorY][A])
#     QB[coorBX, coorBY][B] = QB[coorBX, coorBY][B] + alph*(reward[1] + gamma*np.argmax(QB[obs[1][0], obs[1][1]]) - QB[coorBX, coorBY][B])
#     s1 = obs[0]
#     s2 = obs[1]
#     # render visualization, uncomment to enable visualization
#     with output_grid.output_to(0, 0):
#       output_grid.clear_cell()
#       env.render()
#     time.sleep(0.5)
#     if done:
#       break
#   if epsil < epsil_min:
#     epsil = epsil_min


plt.figure(1)
plt.plot(Q_det_axis, Q_A, label = 'Agent A')
# plt.plot(Q_det_axis, Q_B, label = 'Agent B')

plt.xlabel('Episodes')
plt.ylabel('Rewards')
plt.title('Q Reward agent A')
plt.savefig('Grid_Q_A.jpg')
plt.show()

plt.figure(2)
# plt.plot(Q_det_axis, Q_A, label = 'Agent A')
plt.plot(Q_det_axis, Q_B, label = 'Agent B')

plt.xlabel('Episodes')
plt.ylabel('Rewards')
plt.title('Q Reward agent B')
plt.savefig('Grid_Q_B.jpg')
plt.show()