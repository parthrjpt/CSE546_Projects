import numpy as np
import matplotlib.pyplot as plt
import gym
from gym import spaces
import time
import copy
import random
from collections import deque
import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torch.optim as optim
from torch.autograd import Variable

class MultiAgentEnv(gym.Env):
    """5x5 Environment
      chaser initial state: [0, 0]
      runner initial state: [4, 4]
      portal: [4, 0] and [0, 4], step into one of the portals will teleport to anther portal
    """

    """Chaser gets reward 1 when catching the runner, -1 when runner escaped
      runner gets reward 1 when escaped, -1 otherwise
    """
    def __init__(self):
        self.max_steps = 40
        self.action_space = spaces.Discrete(5)
        self.obs_space = spaces.Discrete(25)
        self.ate = False
        
    def reset(self):
        self.timestep = 0
        self.agentA_pos = [1, 1]
        self.agentB_pos = [4, 4]
        self.teleIn = [4, 0]
        self.teleOut = [0, 4]
        self.state = np.zeros((5, 5))
        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        return observation
    
    def step(self, actionA, actionB):
        if actionA == 0:
          self.agentA_pos[0] += 1
        if actionA == 1:
          self.agentA_pos[0] -= 1
        if actionA == 2:
          self.agentA_pos[1] += 1
        if actionA == 3:
          self.agentA_pos[1] -= 1

        if actionB == 0:
          self.agentB_pos[0] += 1
        if actionB == 1:
          self.agentB_pos[0] -= 1
        if actionB == 2:
          self.agentB_pos[1] += 1
        if actionB == 3:
          self.agentB_pos[1] -= 1
          
        self.agentA_pos = np.clip(self.agentA_pos, 0, 4)
        self.agentB_pos = np.clip(self.agentB_pos, 0, 4)

        if (self.agentA_pos == self.teleIn).all():
          self.agentA_pos = np.copy(self.teleOut)
        elif (self.agentA_pos == self.teleOut).all():
          self.agentA_pos = np.copy(self.teleIn)
        if (self.agentB_pos == self.teleIn).all():
          self.agentB_pos = np.copy(self.teleOut)
        elif (self.agentB_pos == self.teleOut).all():
          self.agentB_pos = np.copy(self.teleIn)
        self.state = np.zeros((5,5))

        self.state[tuple(self.agentA_pos)] = 0.5
        self.state[tuple(self.agentB_pos)] = 1
        observation = (self.agentA_pos, self.agentB_pos)
        done = False
        self.timestep += 1
        rewardA = 0
        rewardB = 0
        if (self.agentA_pos == self.agentB_pos).all():
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[0] == self.agentB_pos[0] and abs(self.agentA_pos[1] -self.agentB_pos[1])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.agentA_pos[1] == self.agentB_pos[1] and abs(self.agentA_pos[0] -self.agentB_pos[0])==1:
          rewardA = 1
          rewardB = -1
          done = True
        if self.timestep ==self.max_steps:
          rewardA = -1
          rewardB = 1
          done = True
        info = {}
        return observation, (rewardA, rewardB), done, info
        
    def render(self):
        plt.imshow(self.state)
class RandomAgent:
    def __init__(self, env):
        self.obs_space = env.obs_space
        self.action_space = env.action_space
        self.env = env
        
    def step(self, observation):
        return np.random.choice(self.action_space.n)

class MTDQNNET(nn.Module):
    def __init__(self, ):
        super(MTDQNNET, self).__init__()
        self.fc1 = nn.Linear(4, 32)
        self.fc1.weight.data.normal_(0, 0.1)
        self.fc2 = nn.Linear(32, 4)
        self.fc2.weight.data.normal_(0, 0.1)
        # self.fc3 = nn.Linear(30, 4)
        # self.fc3.weight.data.normal_(0, 0.1)

    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.fc2(x)
        # x = F.relu(x)
        # x = self.fc3(x)
        return x

BATCH_SIZE = 100
MIN_BATCH_SIZE = 100
MAX_REPLAY_BUFFER_SIZE = 1500
EPSILON = 1

UPDATE = 100
GAMMA = 0.9
# env = DeterEnvironment()

class MTDQNAgent:
    def __init__(self, env):
        self.obs_space = env.obs_space
        # self.encodedstate=np.array(range(0,16))
        self.action_space = env.action_space
        self.env = env
        self.replay_mem = deque(maxlen = MAX_REPLAY_BUFFER_SIZE)
        self.model = MTDQNNET()
        self.target_model = MTDQNNET()
        self.loss_func = nn.MSELoss()
        self.optimizer = optimizer = optim.Adam(self.model.parameters())
        # self.optimizer = optim.SGD(self.model.parameters(), lr=0.001, momentum=0.9)
        self.target_model.fc1.weight = self.model.fc1.weight
        self.target_model.fc2.weight = self.model.fc2.weight
        self.learn_counter = 0
        

    def step(self, x):
        x = Variable(torch.unsqueeze(torch.FloatTensor(x), 0))
        if np.random.uniform() > EPSILON:
          actions = self.model(x)
          action = torch.max(actions, 1)[1].data.numpy()
          action = action[0]
          # print(actions, action)
        else:
          action = np.random.randint(4)
        return action
        
    def store_mem(self, state, action, reward, next_state, done):
      self.replay_mem.append((state, action, reward, next_state, done))

    def train(self):
        if len(self.replay_mem) < MIN_BATCH_SIZE:
          return
        if self.learn_counter % UPDATE == 0:
          # print("----------------------update-----------------")
          # self.target_model.load_state_dict(self.model.state_dict())
          self.target_model.fc1.weight = self.model.fc1.weight
          self.target_model.fc2.weight = self.model.fc2.weight
        self.learn_counter += 1
        batch = random.sample(self.replay_mem, BATCH_SIZE)
        s, a, r, s_, done = (list(col) for col in zip(*batch))

        s = torch.FloatTensor(s)
        a = torch.LongTensor(a)
        r = torch.FloatTensor(r).view(BATCH_SIZE,1)
        s_ = torch.FloatTensor(s_)
        q_val = self.model(s)
        q_next = self.target_model(s_)  

        q_target = torch.tensor([q_next[i].max() for i in range(BATCH_SIZE)])
        q_ = q_val[:, 0]
        for i in range(len(done)):
          q_[i] = q_val[i][a[i]]
          if done[i]:
            q_target[i] = r[i]
        # print(q_.shape, q_target.shape)
        
        q_target = torch.FloatTensor(q_target)

        loss = self.loss_func(q_, q_target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
# def multiDQN():
env = MultiAgentEnv()
env.reset()
agentA = MTDQNAgent(env)
agentB = MTDQNAgent(env)
decay = 0.995
EPSILON = 1
MTDQNplotA=[]
MTDQNplotB=[]
n_games = 1000
k=0
for i in range(n_games):
  env.reset()
  done = False
  culRewardA = 0
  culRewardB = 0
  while not done:
    k+=1
    s = [env.agentA_pos[0], env.agentA_pos[1], env.agentB_pos[0], env.agentB_pos[1]]
    actionA = agentA.step(s)
    actionB = agentB.step(s)
    obs, reward, done, info = env.step(actionA, actionB)
    s_ = [obs[0][0], obs[0][1], obs[1][0], obs[1][1]]
    agentA.store_mem(s, actionA, reward[0], s_, done)
    agentB.store_mem(s, actionB, reward[1], s_,done)
    if k%5 == 1:
      agentA.train()
      agentB.train()
    culRewardA+=reward[0]
    culRewardB+=reward[1]
  # EPSILON = EPSILON*decay if EPSILON > 0.01 else 0.01
  EPSILON = EPSILON - 2/n_games if EPSILON > 0.01 else 0.01
  MTDQNplotA.append(culRewardA)
  MTDQNplotB.append(culRewardB)  

MultiDQNGreedyA= []
MultiDQNGreedyB = []
for i in range(5):
  env.reset()
  done = False
  culRewardA = 0
  culRewardB = 0
  while not done:
    s = [env.agentA_pos[0], env.agentA_pos[1], env.agentB_pos[0], env.agentB_pos[1]]
    actionA = agentA.step(s)
    actionB = agentB.step(s)
    obs, reward, done, info = env.step(actionA, actionB)
    s_ = [obs[0][0], obs[0][1], obs[1][0], obs[1][1]]
    culRewardA+=reward[0]
    culRewardB+=reward[1]
  MultiDQNGreedyA.append(culRewardA)
  MultiDQNGreedyB.append(culRewardB)  

plt.plot(MTDQNplotA)
plt.title('MA agent A reward per ep')
plt.xlabel('episodes')
plt.ylabel('cumulativereward')
plt.savefig('Grid Agent A rewards')

plt.show()
plt.plot(MTDQNplotB)
plt.title('MA agent B reward per ep')
plt.xlabel('episodes')
plt.ylabel('cumulativereward')
plt.savefig('Grid Agent B rewards')
plt.show()

multiEpsilon=[]
EPSILON = 1

while EPSILON>=0.01:
  multiEpsilon.append(EPSILON)
  EPSILON = EPSILON - 2/n_games
  
plt.plot(multiEpsilon)
plt.title('multiagent epsilon')
plt.xlabel('episode')
plt.ylabel('epsilon')
plt.show()